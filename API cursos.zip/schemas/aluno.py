from pydantic import BaseModel

class AlunoCreate(BaseModel):
    id: int
    nome: str
    email: str

class AlunoOut(BaseModel):
    id: int
    nome: str
    email: str