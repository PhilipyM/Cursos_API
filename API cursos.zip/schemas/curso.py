from pydantic import BaseModel

class CursoCreate(BaseModel):
    codigo: int
    titulo: str
    preco: float
    tipo: int   #1 - Gratis | 2 - Pago
    desconto_percentual: float    #opcional

class CursoOut(BaseModel):
    codigo: int
    titulo: str
    preco: float
    tipo: int
    desconto_percentual: float 
