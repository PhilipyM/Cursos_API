class Curso:
    codigo: int
    titulo: str
    preco: float
    tipo: int
    desconto_percentual: float = 0

    def __init__(self, codigo: int, titulo: str, preco: float, tipo: int, desconto_percentual: float = 0):
        if preco < 0:
            raise ValueError("O preço não póde ser menor que 0.")
        
        if desconto_percentual < 0 or desconto_percentual > 100:
            raise ValueError("O valor do deve ser entre 0 e 100.")
        
        if tipo not in [1, 2]:
            raise ValueError("Tipo invalido. Use 1 para gratuito e 2 para pago.")
        
        self.codigo = codigo
        self.titulo = titulo
        self.preco = preco
        self.tipo = tipo
        self.desconto_percentual = desconto_percentual
            

    def preco_final(self, preco: float, tipo: int, desconto_percentual: float) -> float:
        if tipo == 1:   #Torna o valor = 0
            preco_final = 0
            return preco_final
        else:
            if desconto_percentual > 0: #Se ouver desconto, calcula o novo preco
                preco_final = preco - (preco * (desconto_percentual / 100))
                return preco_final
            return preco    #Retorna o preço original (tipo = 2 e desconto = 0)