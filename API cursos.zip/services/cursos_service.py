from domain.aluno import Aluno
from domain.curso import Curso
from repositories.memory import db

id = 1


def criar_aluno(nome: str, email: str):
    aluno = Aluno(nome = nome, email = email, id = id)
    db.alunos[aluno.id] = aluno
    id += 1
    return aluno

def listar_alunos():
    return list(db.alunos.values())

def criar_curso(codigo: int, titulo: str, preco: float, tipo: int, desconto_percentual: float = 0):
    curso = Curso(codigo = codigo, titulo = titulo, preco = preco, tipo = tipo, desconto_percentual = desconto_percentual)
    db.cursos[curso.codigo] = Curso

def listar_cursos():
    return list(db.alunos.values())

def buscar_curso(codigo: int):
    return db.cursos.get(codigo)

def atualizar_preco(codigo: int, novo_preco: float):
    livro = db.livros.get(codigo)
    if not livro:
        return None
    
    if novo_preco < 0:
        raise ValueError("O novo preco não pode ser negativo")
    
    livro.preco = novo_preco
    return livro