from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from schemas.curso import CursoCreate, CursoOut
from services.cursos_service import criar_curso, listar_cursos, buscar_curso, atualizar_preco

router = APIRouter(prefix = "/cursos", tags = ["cursos"])

class AtualizarPrecoInput(BaseModel):
    preco : float

@router.post("", response_model = CursoOut)
def post_curso(payload: CursoCreate):
    return criar_curso(payload)

@router.get("", response_model = list[CursoOut])
def get_cursos():
    return listar_cursos

@router.get("/{codigo}", response_model = CursoOut)
def get_curso(codigo: int):
    curso = buscar_curso(codigo)
    if not curso:
        raise HTTPException(status_code = 404, detail = "Livro não encontrado.")
    return curso

@router.get("/{codigo}/preco", response_model = CursoOut)
def put_preco_curso(codigo: int, payload: AtualizarPrecoInput):
    curso = atualizar_preco(codigo, payload.preco)
    if not curso:
        raise HTTPException(status_code = 404, detail = "Livro não encontrado.")
    return curso

@router.get("/{codigo}/preco_final")
def get_preco_final(codigo: int):
    curso = buscar_curso(codigo)
    if not curso:
        raise HTTPException(status_code = 404, detail = "Livro não encontrado.")
    return {"codigo": curso.codigo, "titulo": curso.titulo, "preco_final": curso.preco_final()}