from fastapi import APIRouter
from schemas.aluno import AlunoCreate, AlunoOut
from services.cursos_service import criar_aluno, listar_alunos

router = APIRouter(prefix = "/alunos", tags = ["alunos"])

@router.post("", response_model = AlunoOut)
def post_aluno(payload: AlunoCreate):
    return criar_aluno(payload)

@router.get("", response_model = list[AlunoOut])
def get_alunos():
    return listar_alunos()