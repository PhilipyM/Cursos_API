from fastapi import FastAPI
from api.routes.aluno import router as alunos_router
from api.routes.curso import router as cursos_router

app = FastAPI(tittle = "Cursos API")

@app.get("/")
def home():
    return{"msg": "Cursos API funcionando!"}
app.include_router(alunos_router)
app.include_router(cursos_router)