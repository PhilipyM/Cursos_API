#from typing import Dict
#from domain.curso import Curso
#from domain.aluno import Aluno

class MemoryDB:
    #def __init__(self):
    #    self.alunos_por_id: Dict[int, Aluno] = {}
    #    self.cursos_por_codigo: Dict[int, Curso] = {}

    def __init__(self):
        self.alunos = {}
        self.cursos = {}

db = MemoryDB()